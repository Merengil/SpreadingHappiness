using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MagicalGirlPlaceholderController : AbstractMagicalGirlController
{
	public bool isAngryAtStart;
	
	// ************************************************************************
	
	public MagicalGirlPlaceholderController () : base()
	{
		angryState = new AngryStatePlaceholder();
		happyState = new HappyStatePlaceholder();
		if (isAngryAtStart)
			magicalGirlState = angryState;
		else magicalGirlState = happyState;
	}
}
