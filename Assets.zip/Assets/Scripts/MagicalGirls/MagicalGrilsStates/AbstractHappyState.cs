using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class AbstractHappyState : AbstractMagicalGirlState
{
	// Shoot in a specific direction
	public override void ShootStraight(Vector2 direction, float force)
	{
		GameObject projectileObject = magicalGirl.Instantiate(projectilePrefab, rigidbody2d.position + Vector2.up * 0.5f, Quaternion.identity);

		BobaBit projectile = projectileObject.GetComponent<BobaBit>();
		projectile.Launch(direction, force);
	}
}
